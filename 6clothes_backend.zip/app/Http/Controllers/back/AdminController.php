<?php

namespace App\Http\Controllers\back;

use App\Http\Controllers\Controller;
use App\Http\Support\Facades\DB;
use App\Models\Product;
use App\Models\product_comment;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Brand;
use App\Models\order;
use App\Models\ProductCategory;
use App\Models\ProductImage;
use Illuminate\Support\Facades\Hash;
class AdminController extends Controller
{
    public function index(){
        $Users=User::all();
        $Products=Product::all();
        $Order=order::all();
        $total = 0;
        foreach ($Order as $key ) {
            $total += $key['total'];
        }
        return view('dashboard.index',compact('Users','Products','Order','total'));
    }
   
}