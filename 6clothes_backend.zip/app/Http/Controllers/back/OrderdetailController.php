<?php

namespace App\Http\Controllers\back;

use App\Http\Controllers\Controller;
use App\Models\order_detaill;
use Illuminate\Http\Request;

class OrderdetailController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $order_detaill = order_detaill::where("order_id",$id)->get();
        $order = $order_detaill->first();
        return view("dashboard.orders.order_detaill",compact("order_detaill","order"));   
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(order_detaill $order_detaill)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, order_detaill $order_detaill)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(order_detaill $order_detaill)
    {
        //
    }
}