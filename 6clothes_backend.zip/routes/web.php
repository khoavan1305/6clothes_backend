<?php

use App\Http\Controllers\back\AdminController;
use App\Http\Controllers\back\OrderController;
use App\Http\Controllers\back\OrderdetailController;
use App\Http\Controllers\back\ProductController;
use App\Http\Controllers\back\CommentController;
use Illuminate\Support\Facades\Route;


/*  
BACK END
*/
//////////////////////////////////////////////////////////////////////////////////

Route::prefix('')->group(function () {
    Route::get('/admin',[AdminController::class,'index'])->name('admin.dashboard');
    Route::resources([
        'user' => App\Http\Controllers\back\UserController::class,
        'product' => ProductController::class,
        'comment' => CommentController::class,
        'order' => OrderController::class,
        // 'brand' => BrandController::class,
        'orderdetail' => OrderdetailController::class,
    ]);
});